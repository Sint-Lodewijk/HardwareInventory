﻿using System.Web.UI;

namespace Toestellenbeheer.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}